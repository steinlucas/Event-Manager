<?php
session_start();
header('Location: /prova/view/login.php');
